﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using EmailValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmailValidation.Tests
{
    [TestClass()]
    public class EmailValidationTests
    {
        [TestMethod()]
        public void LengthCheckerTest()
        {
            // Arrange
            var emailValidation = new EmailValidation();
            var email = "tom.piot83@gmail.com";
            var expected = true;

            //ACT
            var current_status = emailValidation.LengthChecker(email);

            //Assert
            Assert.AreEqual(expected, current_status);
        }

        [TestMethod()]
        public void AtCheckerTest()
        {
            // Arrange
            var emailValidation = new EmailValidation();
            var email = "tom.piot83@gmail.com";
            var expected = true;

            //ACT
            var current_status = emailValidation.AtChecker(email);

            //Assert
            Assert.AreEqual(expected, current_status);
        }

        [TestMethod()]
        public void AtCheckerFalseTest()
        {
            // Arrange
            var emailValidation = new EmailValidation();
            var email = "tom.piot@83@gmail.com";
            var expected = false;

            //ACT
            var current_status = emailValidation.AtChecker(email);

            //Assert
            Assert.AreEqual(expected, current_status);
        }

        [TestMethod()]
        public void DotCheckerTest()
        {
            // Arrange
            var emailValidation = new EmailValidation();
            var email = "tom.piot83@gmail.com";
            var expected = true;

            //ACT
            var current_status = emailValidation.DotChecker(email);

            //Assert
            Assert.AreEqual(expected, current_status);
        }

        [TestMethod()]
        public void DotCheckerFalseTest()
        {
            // Arrange
            var emailValidation = new EmailValidation();
            var email = "tom.piot83@gmailcom";
            var expected = false;

            //ACT
            var current_status = emailValidation.DotChecker(email);

            //Assert
            Assert.AreEqual(expected, current_status);
        }

        [TestMethod()]
        public void DotCheckerWrongDotPositionTest()
        {
            // Arrange
            var emailValidation = new EmailValidation();
            var email = "tom.piot83@gm.ailcom";
            var expected = false;

            //ACT
            var current_status = emailValidation.DotChecker(email);

            //Assert
            Assert.AreEqual(expected, current_status);
        }

        [TestMethod()]
        public void SpaceCheckerTest()
        {

            // Arrange
            var emailValidation = new EmailValidation();
            var email = "tom.pio t83@gmail.com";
            var expected = false;

            //ACT
            var current_status = emailValidation.SpaceChecker(email);

            //Assert
            Assert.AreEqual(expected, current_status);
        }

        [TestMethod()]
        public void EmailCheckerTest()
        {
            // Arrange
            var emailValidation = new EmailValidation();
            var email = "tom.piot83@gmailco.m";
            var expected = false;

            //ACT
            var current_status = emailValidation.EmailChecker(email);

            //Assert
            Assert.AreEqual(expected, current_status);
        }
    }
}