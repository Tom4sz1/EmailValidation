﻿namespace EmailValidation
{
    public class EmailValidation
    {
        
        /// <summary>
        /// A function that checks whether an email address contains at least 6 characters.
        /// </summary>
        /// <param name="email">String e-mail address</param>
        /// <returns>bool</returns>
        public bool LengthChecker(string email)
        {
            bool validation = true;
            if (email.Length < 6)
            {
                validation = false;
            }
            return validation;
        }

        
        /// <summary>
        /// A function that checks whether there is an "@" sign in the email address and whether there is more than one
        /// </summary>
        /// <param name="email">String e-mail address</param>
        /// <returns>bool</returns>
        public bool AtChecker(string email) 
        {
            bool validation = false;
            int atcount = 0;
            foreach (char c in email) 
            {
                if(c == '@')
                {
                    validation = true;
                    atcount++;
                }
            }
            if (atcount > 1) 
            {
                validation = false;
            }
            return validation;
        }

        /// <summary>
        /// A function that checks whether there is a dot in the domain in the E-Mail address, 
        /// whether there is one dot and whether it is third or second from the end.
        /// </summary>
        /// <param name="email">String e-mail address</param>
        /// <returns>bool</returns>
        public bool DotChecker(string email) 
        {
            
            int atposition = email.IndexOf('@');
            string domain = email.Substring(atposition);
            int dotcount = 0;
            foreach (char c in domain) 
            {
                if (c == '.') 
                {
                    dotcount++;
               }
            }

            if (dotcount != 1)
           {
                return false;
            }

            int dotposition = domain.IndexOf('.');

            if (dotposition == -1) 
            {
                return false;
            }

            if (domain.Substring(dotposition).Length - 1 > 3)
            {
                return false;
            }
            if (domain.Substring(dotposition).Length <= 2)
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// A function that checks whether there are no spaces in the email address.
        /// </summary>
        /// <param name="email">String e-mail address</param>
        /// <returns>bool</returns>
        public bool SpaceChecker(string email) 
        {
            bool validation = false;
            if(email.IndexOf(" ") == -1)
            {
                validation = true;
            }
            
            return validation;
        }

        /// <summary>
        /// A function that checks the email address to see if it is correct.
        /// </summary>
        /// <param name="email">String e-mail address</param>
        /// <returns>bool</returns>
        public bool EmailChecker(string email) 
        {
          
           return SpaceChecker(email) && AtChecker(email) && LengthChecker(email) && DotChecker(email);
        }
    }
}
